# GEO1000 - Assignment 2
# Authors:
# Studentnumbers:

def read_grid(filenm):
    """
    """
    pass


def visit(table, steps_allowed, path):
    """
    """
    pass


def hunt(filenm, max_steps):
    """
    """
    pass


if __name__ == "__main__":
    print(hunt('finite.txt', 20))
